import React from 'react';
import Footer from './Footer';
import renderer from 'react-test-renderer';
import { mount } from "enzyme";
 
describe("Footer Test Suite", () => {
  it("should render expected HTML", () => {
    //Mocks
    let classes = { root: { marginTop: "2px" } }
    expect(mount(<Footer classes={classes}/>).html()).toMatchSnapshot();
  });
  it('renders correctly', () => {
    // a virtual dom in json
    const tree = renderer
      .create(<Footer year={2021} company="yoyogift" ></Footer>)
      .toJSON();
    expect(tree).toMatchSnapshot();
    expect(tree).toMatchSnapshot();
  });
});
 
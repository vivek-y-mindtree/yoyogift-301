import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import GiftsList from "../components/GiftsList";
import CircularProgress from "@material-ui/core/CircularProgress";
import Button from "@material-ui/core/Button";
import { fetchCards, fetchCard, fetchCardFilter } from "../state/actions";
import history from "../../common/components/history";
import Select from "@material-ui/core/Select";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import AscendingButton from "@material-ui/icons/SwapVert";
import IconButton from "@material-ui/core/IconButton";
import DescendingButton from "@material-ui/icons/SwapVerticalCircle";
import Tooltip from "@material-ui/core/Tooltip";
import { adminEmail } from '../../../config/constants';
import Grid from '@material-ui/core/Grid';
import { AutoSizer, CellMeasurer, InfiniteLoader, List,  WindowScroller } from 'react-virtualized';
import _ from 'lodash';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import Table from '@material-ui/core/Table';
import TableHead from '@material-ui/core/TableHead';
 
import Paper from '@material-ui/core/Paper';
import TableBody from '@material-ui/core/TableBody';
import {DateFormatter} from '../../common/components/DateFormatter';
import 'react-virtualized/styles.css'
import EditIcon from "@material-ui/icons/BorderColor";
import { Link } from "react-router-dom";
 
import {
  comparePointsAsc,
  comparePointsDesc,
  compareCountAsc,
  compareCountDesc,
  compareValidityAsc,
  compareValidityDesc
} from "../../common/components/CompareForSort";
const rowLimit = 50;
const sortCategoryArray = ["Points", "Count", "Validity"];
const CARD = {

    WIDTH: 320,
  
    HEIGHT: 300
  
  };
class GiftsListContainer extends React.Component {
  constructor(props) {
    super(props);
    console.log('test',props)
    this.state = {
      sortOrder: true,
      sortByValue: "None",
      filterValue: 'All',
      list: props.giftCards,
      loading: false,
      page :1,
    };
  }
 
  componentDidMount() {
    console.log(this.state.list,'this.state.list',this.props.giftCards )
    this.props.fetchCards(this.state.page,rowLimit);
    
    this.setState({  list: this.props.giftCards 
    });
    
  }
 
  isRowLoaded({ index }) {
    return !! this.props.giftCards[index];
  }
  
  loadMoreRows({ startIndex, stopIndex }) {
    console.log(startIndex, stopIndex,'startIndex, stopIndex')
    this.setState({  loading: true,  page: this.state.page + 1
    });
    console.log(this.state.page,'tryuio')
    if(this.state.page > 1 && this.state.page<20) {
        let updatedCards = this.state.list.concat(this.props.giftCards);
         this.setState( {...this.state.list, list: updatedCards});
    }
    else {
      this.setState({ list: this.props.giftCards});
    }
   console.log(this.state.list,'gggssyyysysysysyyysyyyysyysy')
   if(this.state.list.length < 1000) {
    this.props.fetchCards( this.state.page,rowLimit);
   }
    if (this.state.loading) {
      return;
    }
     
    console.log(this.state.page+1,rowLimit,'this.state.page,rowLimit')
  }
  rowRenderer({ key, index, isScrolling, isVisible, style }) {
     if (isVisible) {
      return ( 
        <TableRow  key={key} style={style}>
          <TableCell >{this.state.list[index].cardName}</TableCell>
          <TableCell  >{this.state.list[index].cardPoints}</TableCell>
          <TableCell >{this.state.list[index].receiverEmail}</TableCell>
          <TableCell >{DateFormatter(this.state.list[index].cardIssueDate)}</TableCell>
          <TableCell >{DateFormatter(this.state.list[index].cardExpiryDate)}</TableCell>
          <TableCell >{ this.state.list[index].cardRetailer}</TableCell>
          <TableCell >{ this.state.list[index].cardVendor}</TableCell> 
          <TableCell> 
          {adminEmail.includes(this.props.userDetails.email) ? (
              <Link to={`/AddUpdateForm/${this.props.giftCards[index].id}`}>
               <IconButton>
                  <EditIcon />
                </IconButton>
              </Link>
            ) : null}
          </TableCell>
        </TableRow> 
      );
    }
  }
  cellRenderer({ columnIndex, key, rowIndex, style }) {
    console.log(this.state.list,'twgedksjclssklsaal',key, style);
    return (
       <TableRow  key={key} style={style}>
        <TableCell >{this.props.giftCards[rowIndex].cardName}</TableCell>
        <TableCell  >{this.props.giftCards[rowIndex].cardPoints}</TableCell>
        <TableCell >{this.props.giftCards[rowIndex].receiverEmail}</TableCell>
        <TableCell >{DateFormatter(this.props.giftCards[rowIndex].cardIssueDate)}</TableCell>
        <TableCell >{DateFormatter(this.props.giftCards[rowIndex].cardExpiryDate)}</TableCell>
        <TableCell >{ this.props.giftCards[rowIndex].cardRetailer}</TableCell>
        <TableCell >{ this.props.giftCards[rowIndex].cardVendor}</TableCell>
        <TableCell> 
          {adminEmail.includes(this.props.userDetails.email) ? (
              <Link to={`/AddUpdateForm/${this.props.giftCards[rowIndex].id}`}>
               <IconButton>
                  <EditIcon />
                </IconButton>
              </Link>
            ) : null}
          </TableCell>
      </TableRow>  
    );
  }
  componentDidCatch(error, info) {
    console.log(error);
  }
  handleChangePage = (event, page) => {
    this.setState({ page });
  };

  handleChangeRowsPerPage = event => {
    this.setState({ page: 0, rowsPerPage: event.target.value });
  };

  handleSortButtonClick = () => {
    const e = {
      target: {
        value: this.state.sortByValue
      }
    }
    this.onChangeSort(e)
    this.setState({ sortOrder: !this.state.sortOrder });
  };
  // handleClickCard = (id) => {
  //   this.props.fetchCard(id);
  // }

  // handleUpdateClick = (id) => {
  //   console.log("container id", id);
  //   history.push('/AddUpdateForm/' + id)
  // }

  onChangeRetailer = e => {
    const selectedValue = e.target.value;
    this.setState({
      filterValue: e.target.value
    })
    let newGiftCard = [];
    if (selectedValue !== "All") {
      this.props.giftCards.forEach(element => {
        if (element.cardRetailer === selectedValue) {
          newGiftCard.push(element);
        }
      });
    } else {
      newGiftCard = this.props.giftCards;
    }
    this.props.fetchCardFilter(newGiftCard)
  };

  onChangeSort = e => {
    const { sortOrder } = this.state;
    const giftCards = this.state.filterValue === 'All' ? this.props.giftCards : this.props.giftCardsFiltered;
    this.setState({
      sortByValue: e.target.value,
      sortOrder: !this.state.sortOrder
    })
    let newGiftCard = giftCards;
    if (e.target.value !== "None") {
      switch (e.target.value) {
        case "Points":
          newGiftCard = sortOrder
            ? giftCards.sort(comparePointsAsc)
            : giftCards.sort(comparePointsDesc);
          break;
        case "Count":
          newGiftCard = sortOrder
            ? giftCards.sort(compareCountAsc)
            : giftCards.sort(compareCountDesc);
          break;
        case "Validity":
          newGiftCard = sortOrder
            ? giftCards.sort(compareValidityAsc)
            : giftCards.sort(compareValidityDesc);
          break;
        default:
      }
    }
    this.props.fetchCardFilter(newGiftCard);
  };

  addUpdateForm = () => {
    history.push("/AddUpdateForm");
  };

  render() {
      console.log(this.props.giftCards.length,'this.props.giftCards.lengt')
    if (this.props.giftCards.length === 0) {
      return (
        <CircularProgress style={{ marginLeft: "50%", marginTop: "10%" }} />
      );
    }
    let cardRetailerArray = [];
    for (let i = 0; i < this.props.giftCards.length; i++) {
      cardRetailerArray.push(this.props.giftCards[i].cardRetailer);
    }
    let uniqueCardRetailerArray = [...new Set(cardRetailerArray)];
    // return (
    //   <React.Fragment>
       
    //     <Grid container spacing={0}>
    //       <Grid item xs={12} sm={3}>
    //         <label style={{ marginLeft: "2%" }}>Filter by Retailer:</label>
    //         <Select
    //           style={{
    //             marginLeft: "2%",
    //             marginTop: "2%",
    //             width: "100px",
    //             height: "35px"
    //           }}
    //           native
    //           onChange={this.onChangeRetailer}
    //           input={<OutlinedInput labelWidth={0} name="kpiValue" />}
    //         >
    //           <option value="All">All</option>
    //           {uniqueCardRetailerArray.map(option => {
    //             return <option value={option}>{option}</option>;
    //           })}
    //         </Select>
    //       </Grid>
    //       <Grid item xs={12} sm={3}>
    //         <label style={{ marginLeft: "2%" }}>Sort by:</label>
    //         <Select
    //           style={{
    //             marginLeft: "2%",
    //             marginTop: "2%",
    //             marginRight: "2%",
    //             width: "100px",
    //             height: "35px"
    //           }}
    //           native
    //           onChange={this.onChangeSort}
    //           input={<OutlinedInput labelWidth={0} name="sortByValue" />}
    //         >
    //           <option value="None">None</option>
    //           {sortCategoryArray.map(option => {
    //             return <option value={option}>{option}</option>;
    //           })}
    //         </Select>
    //         {this.state.sortOrder ? (
    //           <Tooltip
    //             title={
    //               this.state.sortByValue === "Validity"
    //                 ? "Oldest to Newest"
    //                 : "Low to High"
    //             }
    //           >
    //             <IconButton
    //               onClick={this.handleSortButtonClick}
    //               disabled={this.state.sortByValue === 'None'}>
    //               <AscendingButton />
    //             </IconButton>
    //           </Tooltip>
    //         ) : (
    //             <Tooltip
    //               title={
    //                 this.state.sortByValue === "Validity"
    //                   ? "Newest to Oldest"
    //                   : "High to Low"
    //               }
    //             >
    //               <IconButton onClick={this.handleSortButtonClick}>
    //                 <DescendingButton />
    //               </IconButton>
    //             </Tooltip>
    //           )}
    //       </Grid>
    //       <Grid item xs={12} sm={3}>
    //         {adminEmail.includes(this.props.userDetails.email) ? (
    //           <Button
    //             style={{ marginTop: "2%", marginRight: "3%", marginLeft: "2%" }}
    //             variant="contained"
    //             color="primary"
    //             onClick={this.addUpdateForm}
    //           >
    //             ADD CARD
    //       </Button>
    //         ) : null}
    //       </Grid>
    //       {/* <Grid item xs={12} sm={3}>
    //           search bar:<input name="SearchBar" />
    //       </Grid> */}
    //     </Grid>

    //     <div style={{ textAlign: 'center' }}>
    //       <GiftsList
    //         {...this.props}
    //         handleClickCard={this.handleClickCard}
    //         handleUpdateClick={this.handleUpdateClick}
    //       />
    //     </div>
    //   </React.Fragment>
    // );
    return (
      <div>
        <React.Fragment>
       
           <Grid container spacing={0}>
              <Grid item xs={12} sm={3}>
               <label style={{ marginLeft: "2%" }}>Filter by Retailer:</label>
              <Select
                 style={{
                   marginLeft: "2%",
                   marginTop: "2%",
                   width: "100px",
                   height: "35px"
                 }}
                 native
                 onChange={this.onChangeRetailer}
                 input={<OutlinedInput labelWidth={0} name="kpiValue" />}
               >
                 <option value="All">All</option>
                 {uniqueCardRetailerArray.map(option => {
                   return <option value={option}>{option}</option>;
                 })}
               </Select>
             </Grid>
             <Grid item xs={12} sm={3}>
               <label style={{ marginLeft: "2%" }}>Sort by:</label>
               <Select
                 style={{
                   marginLeft: "2%",
                   marginTop: "2%",
                   marginRight: "2%",
                   width: "100px",
                   height: "35px"
                 }}
                 native
                 onChange={this.onChangeSort}
                 input={<OutlinedInput labelWidth={0} name="sortByValue" />}
               >
                 <option value="None">None</option>
                 {sortCategoryArray.map(option => {
                   return <option value={option}>{option}</option>;
                 })}
               </Select>
               {this.state.sortOrder ? (
                 <Tooltip
                   title={
                     this.state.sortByValue === "Validity"
                       ? "Oldest to Newest"
                       : "Low to High"
                   }
                 >
                   <IconButton
                     onClick={this.handleSortButtonClick}
                     disabled={this.state.sortByValue === 'None'}>
                     <AscendingButton />
                   </IconButton>
                 </Tooltip>
               ) : (
                   <Tooltip
                     title={
                       this.state.sortByValue === "Validity"
                         ? "Newest to Oldest"
                         : "High to Low"
                     }
                   >
                     <IconButton onClick={this.handleSortButtonClick}>
                       <DescendingButton />
                     </IconButton>
                   </Tooltip>
                 )}
             </Grid>
             <Grid item xs={12} sm={3}>
               {adminEmail.includes(this.props.userDetails.email) ? (
                 <Button
                   style={{ marginTop: "2%", marginRight: "3%", marginLeft: "2%" }}
                   variant="contained"
                   color="primary"
                   onClick={this.addUpdateForm}
                 >
                   ADD CARD
             </Button>
               ) : null}
             </Grid>
             {/* <Grid item xs={12} sm={3}>
                 search bar:<input name="SearchBar" />
             </Grid> */}
           </Grid>
   
           {/* <div style={{ textAlign: 'center' }}>
             <GiftsList
               {...this.props}
               handleClickCard={this.handleClickCard}
               handleUpdateClick={this.handleUpdateClick}
             />
           </div> */}
         </React.Fragment>
          <Table style={{width: '87%'}}>
            <TableHead>
              <TableRow>
                <TableCell>Card Name</TableCell>
                <TableCell align="right">Card Points</TableCell>
                {/* <TableCell align="right">Receiver Email</TableCell> */} 
                <TableCell align="right">Card Issue Date</TableCell>
                <TableCell align="right">Card Expiry Date</TableCell>
                <TableCell align="right">Card Retailer</TableCell>
                <TableCell align="right">Card Vendor</TableCell>
              </TableRow>
            </TableHead>
           <TableBody>
           <InfiniteLoader
          isRowLoaded={isRowLoaded => this.isRowLoaded(isRowLoaded)}
          loadMoreRows={loadMoreRows => this.loadMoreRows(loadMoreRows)}
          rowCount={this.state.list.length+1}
           
        >
          {({ onRowsRendered, registerChild }) => (
               
             <AutoSizer disableHeight>
             {( { width, scrollTop  } ) => (
                 <List
                     height={400}
                     onRowsRendered={onRowsRendered}
                     ref={registerChild}
                     rowCount={this.state.list.length}
                     rowHeight={60}
                     rowRenderer={rowRenderer => this.rowRenderer(rowRenderer)}
                     width={width}
                     scrollTop={scrollTop}
                 />
             )}
            </AutoSizer>
        
          )}
        </InfiniteLoader>
           </TableBody>
          </Table>
        
        
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    giftCards: state.gifts.giftCards,
    giftCardsFiltered: state.gifts.giftCardsFiltered,
    userDetails: state.login.detailsObject
  };
};

GiftsListContainer.propTypes = {
  classes: PropTypes.object.isRequired
};

export default connect(
  mapStateToProps,
  { fetchCards, fetchCard, fetchCardFilter }
)(GiftsListContainer);

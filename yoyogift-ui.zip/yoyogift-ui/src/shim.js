//for react testing
// mocking requestAnimationFrame as we don't have browser
const raf = global.requestAnimationFrame = (cb) => {
    setTimeout(cb, 0)
}
  
export default raf

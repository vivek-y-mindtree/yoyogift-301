export const apiURL = 'http://localhost:5000'
export const adminEmail = [
    "kumarvivek25101@gmail.com",
]
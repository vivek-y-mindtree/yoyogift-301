import React from 'react';
import { shallow, mount, render } from 'enzyme';
 import LandingPage from './modules/landing/Landing';
// describe what we are testing
describe('LandingPage Component', () => {
 
    // make our assertion and what we expect to happen 
    it('should render without throwing an error', () => {
      expect(shallow(<LandingPage />).exists()).toBe(true)
    })
    it('should render without throwing grid', () => {
         expect(shallow(<LandingPage />).find('Grid').length) 
    })  
  
    it('able to find an html element by class', () => {
        expect(shallow(<LandingPage />).find('.abc').html())
         .toContain('YoYo makes it easy for you to give the perfect gift card');
    });
    it('able to find an html element by id', () => {
        expect(shallow(<LandingPage />).find('#randomId').html())
         .toContain('and conveniently manage them from any device!!');
    });
   
})  
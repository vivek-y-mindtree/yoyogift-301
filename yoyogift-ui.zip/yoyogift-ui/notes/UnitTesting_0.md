-- Unit Testing/White box testing
-- Test a function or code logic
-- V.doms - render output
-- mocks
-- stubs

-- Jasmine - test library 
-- JEST - Test runner - run the test case
            JEST integrate jasmine in its core  + plus more functionalities

-- REAL DOM, in place browser, jsdom libraries used
-- jsdom is a library, that mimic browser in headless environment
-- enzyme - useful to test components 
            -- render
            -- mount
            -- shallow


-- to run the test cases, we can use `npm test`



-- ensure that you have setupTests.js in your src folder
-- setupTests.js is first file to be executed by JEST runtime to initialize test runtime/startup/bootstrap/global
-- setup shim.js in src folder, that contains any brower mock/hack


your test files either stored as .test.js or .spec.js file.

JESt will find the files and execute them.

store the test files on the same folder..


